// Copyright 2022 Apetrei Lavinia-Georgiana
#ifndef COMMANDS_H_
#define COMMANDS_H_

#include <stdio.h>
#include <stdlib.h>

#include "structs.h"
#include "errors.h"

void add_deck(doubly_linked_list_t *list_of_decks, int nr_cards);

void add_cards
(doubly_linked_list_t *list_of_decks, int deck_index, int nr_cards);

void deck_number(doubly_linked_list_t *list_of_decks);

void deck_len(doubly_linked_list_t *list_of_decks, int deck_index);

void show_deck(doubly_linked_list_t *list_of_decks, int deck_index);

void show_all(doubly_linked_list_t *list_of_decks);

void del_card(doubly_linked_list_t *list_of_decks,
			int deck_index, int card_index, int del_card_com);

void del_deck
(doubly_linked_list_t *list_of_decks, int deck_index, int del_deck_com);

void shuffle_deck(doubly_linked_list_t *list_of_decks, int deck_index);

void reverse_deck(doubly_linked_list_t *list_of_decks, int deck_index);

void split_deck
(doubly_linked_list_t *list_of_decks, int deck_index, int split_index);

void merge_decks
(doubly_linked_list_t *list_of_decks, int deck_index_1, int deck_index_2);

void sort_deck(doubly_linked_list_t *list_of_decks, int deck_index);

int index_symbol(char *symbol);

#endif  // COMMANDS_H_
