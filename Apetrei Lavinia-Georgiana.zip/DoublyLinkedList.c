// Copyright 2022 Apetrei Lavinia-Georgiana
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DoublyLinkedList.h"
#include "structs.h"

// functie care creeaza un nod si il returneaza
dll_node_t *
create_node(const void* new_data, unsigned int data_size)
{
    dll_node_t *node;
    node = malloc(sizeof(*node));
    if (node == NULL) {
        fprintf(stderr, "malloc failed");
        return NULL;
    }

    node->data = malloc(data_size);
    if (node->data == NULL) {
        fprintf(stderr, "malloc failed");
        return NULL;
    }
    memcpy(node->data, new_data, data_size);
    return node;
}

// functie care creeaza o lista dublu inlantuita si
// o returneaza
doubly_linked_list_t*
dll_create(unsigned int data_size)
{
    doubly_linked_list_t *list;

    list = malloc(sizeof(*list));
    if (list == NULL) {
        fprintf(stderr, "malloc failed");
        return NULL;
    }

    list->head = NULL;
    list->data_size = data_size;
    list->size = 0;

    return list;
}

// functie care determina al n-lea nod dintr-o lista si il returneaza
dll_node_t*
dll_get_nth_node(doubly_linked_list_t* list, unsigned int n)
{
    if (list->size == 0 || list == NULL) {
        return NULL;
    }

    dll_node_t *node = list->head;
    if (n >= list->size) {
        n = list->size - 1;
    }
    for (ui i = 0; i < n; i++) {
        node = node->next;
    }

    return node;
}

// functie care adauga un nod pe pozitia n intr-o lista
void dll_add_nth_node
(doubly_linked_list_t* list, unsigned int n, const void* new_data)
{
    dll_node_t *node, *curr_node, *prev_node;
    if (list == NULL) {
        return;
    }

    if (n >= list->size) {
        n = list->size;
    }

    node = create_node(new_data, list->data_size);

    if (!list->size) {
        node->next = NULL;
        node->prev = NULL;
        list->head = node;
    } else if (n == 0) {
        curr_node = list->head;
        node->next = curr_node;
        node->prev = NULL;
        curr_node->prev = node;
        list->head = node;
    } else if (n == list->size) {
        prev_node = dll_get_nth_node(list, n -1);
        node->next = NULL;
        prev_node->next = node;
        node->prev = prev_node;
    } else {
        prev_node = dll_get_nth_node(list, n -1);
        node->next = prev_node->next;
        prev_node->next->prev = node;

        prev_node->next = node;
        node->prev = prev_node;
    }

    list->size++;
}

// functie care sterge si returneaza nodul de pe pozitia n,
// urmand a fi eliberata memoria ocupata de acesta ulterior
dll_node_t*
dll_remove_nth_node(doubly_linked_list_t* list, unsigned int n)
{
    dll_node_t *removed;

    if (list == NULL) {
        return NULL;
    }

    if (n >= list->size) {
        n = list->size - 1;
    }

    if (n > 0 && (n < list->size - 1)) {
        removed = dll_get_nth_node(list, n);
        removed->next->prev = removed->prev;
        removed->prev->next = removed->next;
    } else if (list->size == 1) {
        removed = dll_get_nth_node(list, n);
    } else if (n == 0) {
        removed = list->head;
        list->head = removed->next;
        removed->next->prev = NULL;
    } else if (n == list->size - 1) {
        removed = dll_get_nth_node(list, n);
        removed->prev->next = NULL;
    }

    list->size--;

    if (list->size == 0) {
        list->head = NULL;
    }

    return removed;
}

// functie care elibereaza memoria ocupata de o lista
void
dll_free(doubly_linked_list_t** pp_list)
{
    dll_node_t *removed;

    if (pp_list == NULL || *pp_list == NULL)
        return;

    while ((*pp_list)->size) {
        removed = dll_remove_nth_node(*pp_list, 0);
        free(removed->data);
        free(removed);
    }

    free(*pp_list);
    *pp_list = NULL;
}

