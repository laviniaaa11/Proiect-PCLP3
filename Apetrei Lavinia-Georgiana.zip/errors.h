// Copyright 2022 Apetrei Lavinia-Georgiana
#ifndef ERRORS_H_
#define ERRORS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "structs.h"

int deck_index_out_of_bounds(int index, int length);

int card_index_out_of_bounds(int index, int length, int deck_index);

int invalid_card(int value, char *symbol);

int invalid_command(char *string, ui *param1, ui *param2);

int nr_param(char *string, int *value, char *symbol);

#endif  // ERRORS_H_
