// Copyright 2022 Apetrei Lavinia-Georgiana
#ifndef DOUBLYLINKEDLIST_H_
#define DOUBLYLINKEDLIST_H_

#include <stdio.h>
#include <stdlib.h>

#include "structs.h"

dll_node_t *create_node(const void* new_data, unsigned int data_size);

doubly_linked_list_t* dll_create(unsigned int data_size);

dll_node_t* dll_get_nth_node(doubly_linked_list_t* list, unsigned int n);

void dll_add_nth_node
(doubly_linked_list_t* list, unsigned int n, const void* new_data);

dll_node_t* dll_remove_nth_node(doubly_linked_list_t* list, unsigned int n);

void dll_free(doubly_linked_list_t** list);

#endif  // DOUBLYLINKEDLIST_H_
