// Copyright 2022 Apetrei Lavinia-Georgiana
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "commands.h"
#include "DoublyLinkedList.h"
#include "structs.h"
#include "errors.h"

#define SMAX 20
#define CMAX 256

// functie care adauga la lista de pachete un deck cu "nr_cards" carti
void
add_deck(doubly_linked_list_t *list_of_decks, int nr_cards)
{
    if (!list_of_decks) {
        return;
    }
    doubly_linked_list_t *deck = dll_create(sizeof(card_t));
    dll_add_nth_node(list_of_decks, list_of_decks->size, deck);
    add_cards(list_of_decks, list_of_decks->size - 1, nr_cards);

    free(deck);

    printf("The deck was successfully created with %d cards.\n", nr_cards);
}

// functie care adauga "nr_cards" carti in pachetul cu indicele "deck_index"
void
add_cards(doubly_linked_list_t *list_of_decks, int deck_index, int nr_cards)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    char command[CMAX];
    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);

    card_t *aux_card;
    aux_card = malloc(sizeof(*aux_card));

    int valid_cards = 0;
    while (valid_cards != nr_cards) {
        fgets(command, CMAX, stdin);
        // linia ce contine caracteristicile unei carti
        if (!nr_param(command, &aux_card->value, aux_card->symbol))
        {
            if (!invalid_card(aux_card->value, aux_card->symbol)) {
                valid_cards++;
                dll_add_nth_node(node->data,
                ((doubly_linked_list_t *)(node->data))->size, aux_card);
            }
        } else {
            printf("The provided card is not a valid one.\n");
        }
    }

    free(aux_card);
}

// afiseaza numarul de pachete din lista de pachete
void deck_number(doubly_linked_list_t *list_of_decks)
{
    if (!list_of_decks)
        return;

    printf("The number of decks is %d.\n", list_of_decks->size);
}

// afiseaza numarul de carti dintr-un pachet
void deck_len(doubly_linked_list_t *list_of_decks, int deck_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;

    printf("The length of deck %d is %d.\n", deck_index, deck->size);
}

// functia care afiseaza pachetul de la indexul "deck_index"
void show_deck(doubly_linked_list_t *list_of_decks, int deck_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;
    printf("Deck %d:\n", deck_index);
    for (ui i = 0; i < deck->size; i++) {
        dll_node_t *card = dll_get_nth_node(deck, i);
        printf("\t%d %s\n", ((card_t *)(card->data))->value,
        ((card_t *)(card->data))->symbol);
    }
}

// functie care afiseaza toate pachetele din lista
void show_all(doubly_linked_list_t *list_of_decks)
{
    if (!list_of_decks)
        return;

    for (ui i = 0; i < list_of_decks->size; i++) {
        show_deck(list_of_decks, i);
    }
}

// functie care sterge o carte dintr-un pachet dat
void del_card(doubly_linked_list_t *list_of_decks,
int deck_index, int card_index, int del_card_com)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;
    if (card_index_out_of_bounds(card_index, deck->size, deck_index))
        return;

    dll_node_t *removed = dll_remove_nth_node(deck, card_index);
    free(removed->data);
    free(removed);

    // del_card este folosita si de alte functii si nu vreau ca acest mesaj
    // sa fie afisat in alte contexte
    if (del_card_com)
        printf("The card was successfully deleted from deck %d.\n", deck_index);

    if (deck->size == 0 && del_card_com) {
        free(deck);
        node = dll_remove_nth_node(list_of_decks, deck_index);
        free(node);
    }
}

// functie care elimina un pachet din lista
void del_deck(doubly_linked_list_t *list_of_decks,
int deck_index, int del_deck_com)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;

    for (int i = deck->size - 1; i >= 0; i--) {
        del_card(list_of_decks, deck_index, i, 0);
    }

    free(deck);

    dll_node_t * removed  = dll_remove_nth_node(list_of_decks, deck_index);
    free(removed);

    if (del_deck_com)
        printf("The deck %d was successfully deleted.\n", deck_index);
}

// functie care inverseaza cartile dintr-un pachet
void reverse_deck(doubly_linked_list_t *list_of_decks, int deck_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_remove_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;
    doubly_linked_list_t *aux_deck = dll_create(sizeof(card_t));


    for (int i = deck->size - 1; i >= 0; i--) {
        dll_add_nth_node(aux_deck, aux_deck->size,
        dll_get_nth_node(deck, i)->data);
    }

    dll_add_nth_node(list_of_decks, deck_index, aux_deck);
    free(aux_deck);
    dll_free(&deck);
    free(node);
    printf("The deck %d was successfully reversed.\n", deck_index);
}

// functie care imparte un pachet dupa un anumit index, rezultand doua pachete
void split_deck(doubly_linked_list_t *list_of_decks,
int deck_index, int split_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_get_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;
    if (card_index_out_of_bounds(split_index, deck->size, deck_index))
        return;

    printf("The deck %d was successfully split by index %d.\n",
    deck_index, split_index);

    if (split_index == 0) {
        return;
    }

    doubly_linked_list_t *aux_deck = dll_create(sizeof(card_t));

    for (ui i = split_index; i < deck->size; i++) {
        dll_add_nth_node(aux_deck, aux_deck->size,
        dll_get_nth_node(deck, i)->data);
    }
    for (int i = deck->size - 1; i >= split_index; i--) {
        del_card(list_of_decks, deck_index, i, 0);
    }
    dll_add_nth_node(list_of_decks, deck_index + 1, aux_deck);
    free(aux_deck);
}

// functie care combina doua pachete, luand cate o carte din fiecare pachet
void merge_decks(doubly_linked_list_t *list_of_decks,
int deck_index_1, int deck_index_2)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index_1, list_of_decks->size))
        return;

    if (deck_index_out_of_bounds(deck_index_2, list_of_decks->size))
        return;

    dll_node_t *node_1 = dll_get_nth_node(list_of_decks, deck_index_1);
    doubly_linked_list_t *deck_1 = node_1->data;

    dll_node_t *node_2 = dll_get_nth_node(list_of_decks, deck_index_2);
    doubly_linked_list_t *deck_2 = node_2->data;

    doubly_linked_list_t *deck_3 = dll_create(sizeof(card_t));

    ui index_1 = 0, index_2 = 0;
    while (index_1 < deck_1->size && index_2 < deck_2->size) {
        dll_add_nth_node(deck_3, deck_3->size,
        dll_get_nth_node(deck_1, index_1)->data);

        dll_add_nth_node(deck_3, deck_3->size,
        dll_get_nth_node(deck_2, index_2)->data);
        index_1++;
        index_2++;
    }

    while (index_1 < deck_1->size) {
        dll_add_nth_node(deck_3, deck_3->size,
        dll_get_nth_node(deck_1, index_1)->data);
        index_1++;
    }

    while (index_2 < deck_2->size) {
        dll_add_nth_node(deck_3, deck_3->size,
        dll_get_nth_node(deck_2, index_2)->data);
        index_2++;
    }

    dll_add_nth_node(list_of_decks, list_of_decks->size, deck_3);
    free(deck_3);

    if (deck_index_1 > deck_index_2) {
        del_deck(list_of_decks, deck_index_1, 0);
        del_deck(list_of_decks, deck_index_2, 0);
    } else {
        del_deck(list_of_decks, deck_index_2, 0);
        del_deck(list_of_decks, deck_index_1, 0);
    }

    printf("The deck %d and the deck %d were successfully merged.\n",
    deck_index_1, deck_index_2);
}

// functie care imparte un pachet in doua jumatati si le inverseaza
void shuffle_deck(doubly_linked_list_t *list_of_decks, int deck_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
        return;

    dll_node_t *node = dll_remove_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;

    doubly_linked_list_t *new_deck = dll_create(sizeof(card_t));

    for (ui i = deck->size / 2; i < deck->size; i++) {
        dll_add_nth_node(new_deck, new_deck->size,
        dll_get_nth_node(deck, i)->data);
    }
    for (ui i = 0; i < deck->size / 2; i++) {
        dll_add_nth_node(new_deck, new_deck->size,
        dll_get_nth_node(deck, i)->data);
    }

    dll_add_nth_node(list_of_decks, deck_index, new_deck);
    free(new_deck);
    dll_free(&deck);
    free(node);
    printf("The deck %d was successfully shuffled.\n", deck_index);
}

// functie care sorteaza cartile dintr-un pachet, in
// functie de valoare si simbol
void sort_deck(doubly_linked_list_t *list_of_decks, int deck_index)
{
    if (!list_of_decks)
        return;

    if (deck_index_out_of_bounds(deck_index, list_of_decks->size))
       return;

    dll_node_t *node = dll_remove_nth_node(list_of_decks, deck_index);
    doubly_linked_list_t *deck = node->data;

    doubly_linked_list_t *new_deck = dll_create(sizeof(card_t));

    int pos_min, sym, val_min;
    while (deck->size) {
        pos_min = 0;
        val_min = ((card_t *)(dll_get_nth_node(deck, 0)->data))->value;
        sym = index_symbol(((card_t *)dll_get_nth_node(deck, 0)->data)->symbol);
        for (ui i = 0; i < deck->size; i++) {
            card_t *card = dll_get_nth_node(deck, i)->data;
            if (card->value < val_min) {
                val_min = card->value;
                pos_min = i;
                sym = index_symbol(((card_t *)
                    dll_get_nth_node(deck, i)->data)->symbol);
            } else if (card->value == val_min && sym > index_symbol(((card_t *)
                    dll_get_nth_node(deck, i)->data)->symbol)){
                pos_min = i;
                sym = index_symbol(((card_t *)
                    dll_get_nth_node(deck, i)->data)->symbol);
            }
        }
        dll_add_nth_node(new_deck, new_deck->size,
                        dll_get_nth_node(deck, pos_min)->data);
        dll_node_t *removed = dll_remove_nth_node(deck, pos_min);
        free(removed->data);
        free(removed);
    }
    dll_free(&deck);
    free(node);
    dll_add_nth_node(list_of_decks, deck_index, new_deck);
    free(new_deck);
    printf("The deck %d was successfully sorted.\n", deck_index);
}

// am mapat fiecarei carti un numar
// HEART = 0
// SPADE = 1
// DIAMOND = 2
// CLUB = 3
int index_symbol(char *symbol)
{
    if (strcmp(symbol, "HEART") == 0) {
        return 0;
    } else if (strcmp(symbol, "SPADE") == 0) {
        return 1;
    } else if (strcmp(symbol, "DIAMOND") == 0) {
        return 2;
    } else if (strcmp(symbol, "CLUB") == 0) {
        return 3;
    }
    return -1;
}
