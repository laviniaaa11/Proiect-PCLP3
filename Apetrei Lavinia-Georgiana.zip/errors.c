// Copyright 2022 Apetrei Lavinia-Georgiana
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "errors.h"
#include "structs.h"

// in acest fisier au fost implementate functii pentru erori

int deck_index_out_of_bounds(int index, int length)
{
	if (index < 0 || index >= length) {
		printf("The provided index is out of bounds for the deck list.\n");
		return 1;
	}
	return 0;
}

int card_index_out_of_bounds(int index, int length, int deck_index)
{
	if (index < 0 || index >= length) {
		printf("The provided index is out of bounds for deck %d.\n", deck_index);
		return 1;
	}
	return 0;
}

int invalid_card(int value, char *symbol)
{
	if (value < 0 || value > 14 || (strcmp(symbol, "HEART") &&
		strcmp(symbol, "SPADE") && strcmp(symbol, "DIAMOND") &&
		strcmp(symbol, "CLUB"))) {
		printf("The provided card is not a valid one.\n");
			return 1;
	}
	return 0;
}

int invalid_command(char *string, ui *param1, ui *param2)
{
	int nr_of_parameters = -1;
	char *token, *command = strtok(string, " \n");
	token = command;
	while (token != NULL) {
		++nr_of_parameters;
		if (nr_of_parameters == 1) {
			*param1 = atoi(token);
		} else if (nr_of_parameters == 2) {
			*param2 = atoi(token);
		}
		token = strtok(NULL, " ");
	}

	if (strcmp(command, "ADD_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "DEL_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "DEL_CARD") == 0) {
		if (nr_of_parameters != 2)
			return 1;
	} else if (strcmp(command, "ADD_CARDS") == 0) {
		if (nr_of_parameters != 2)
			return 1;
	} else if (strcmp(command, "DECK_NUMBER") == 0) {
		if (nr_of_parameters != 0)
			return 1;
	} else if (strcmp(command, "DECK_LEN") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "SHUFFLE_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "MERGE_DECKS") == 0) {
		if (nr_of_parameters != 2)
			return 1;
	} else if (strcmp(command, "SPLIT_DECK") == 0) {
		if (nr_of_parameters != 2)
			return 1;
	} else if (strcmp(command, "REVERSE_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "SHOW_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else if (strcmp(command, "SHOW_ALL") == 0) {
		if (nr_of_parameters != 0)
			return 1;
	} else if (strcmp(command, "EXIT") == 0) {
		if (nr_of_parameters != 0)
			return 1;
	} else if (strcmp(command, "SORT_DECK") == 0) {
		if (nr_of_parameters != 1)
			return 1;
	} else {
		return 1;
	}
	return 0;
}

// functie care verifica daca numarul de caracteristici ale unei carti
// este corect si care returneaza valoarea si simbolul acesteia
int nr_param(char *string, int *value, char *symbol)
{
	int nr_of_parameters = 0;
	char *token = strtok(string, " \n");
	while (token != NULL) {
		++nr_of_parameters;
		if (nr_of_parameters == 1) {
			*value = atoi(token);
		} else if (nr_of_parameters == 2) {
			strcpy(symbol, token);
		}
		token = strtok(NULL, " \n");
	}

	if (nr_of_parameters != 2)
		return 1;

	return 0;
}
