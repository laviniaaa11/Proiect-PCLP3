// Copyright 2022 Apetrei Lavinia-Georgiana
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DoublyLinkedList.h"
#include "commands.h"
#include "structs.h"
#include "errors.h"

#define CMAX 256

int main(void)
{
	// declararea listei de deck-uri
	doubly_linked_list_t *list_of_decks = dll_create(sizeof(*list_of_decks));
	// in acest string se citeste, pe rand, fiecare linie din fisierul de intrare
    char command[CMAX];
    ui param1, param2;  // parametrii comenzilor

    while (1) {
    	fgets(command, CMAX, stdin);
    	if (invalid_command(command, &param1, &param2)) {
    		printf("Invalid command. Please try again.\n");
    	} else {
    		if (strcmp(command, "ADD_DECK") == 0) {
    			add_deck(list_of_decks, param1);
    		} else if (strcmp(command, "EXIT") == 0) {
    			break;
    		} else if (strcmp(command, "ADD_CARDS") == 0) {
    			add_cards(list_of_decks, param1, param2);
    			if (param1 < list_of_decks->size) {
    				printf("The cards were successfully added to deck %d.\n", param1);
    			}
    		} else if (strcmp(command, "DECK_NUMBER") == 0) {
    			deck_number(list_of_decks);
    		} else if (strcmp(command, "DECK_LEN") == 0) {
    			deck_len(list_of_decks, param1);
    		} else if (strcmp(command, "SHOW_DECK") == 0) {
    			show_deck(list_of_decks, param1);
    		} else if (strcmp(command, "SHOW_ALL") == 0) {
    			show_all(list_of_decks);
    		} else if (strcmp(command, "DEL_CARD") == 0) {
    			del_card(list_of_decks, param1, param2, 1);
    		} else if (strcmp(command, "DEL_DECK") == 0) {
    			del_deck(list_of_decks, param1, 1);
    		} else if (strcmp(command, "SHUFFLE_DECK") == 0) {
    			shuffle_deck(list_of_decks, param1);
    		} else if (strcmp(command, "REVERSE_DECK") == 0) {
    			reverse_deck(list_of_decks, param1);
    		} else if (strcmp(command, "SPLIT_DECK") == 0) {
    			split_deck(list_of_decks, param1, param2);
    		} else if (strcmp(command, "MERGE_DECKS") == 0) {
    			merge_decks(list_of_decks, param1, param2);
    		} else if (strcmp(command, "SORT_DECK") == 0) {
    			sort_deck(list_of_decks, param1);
    		}
    	}
    }

    // eliberarea memoriei ocupate de lista de deck-uri si de
    // fiecare deck in parte
    for (int i = list_of_decks->size - 1; i >= 0; i--) {
    	dll_node_t *aux = dll_get_nth_node(list_of_decks, i);
    	doubly_linked_list_t *deck = aux->data;
    	dll_free(&deck);
    	free(aux);
    }
    free(list_of_decks);
    return 0;
}
