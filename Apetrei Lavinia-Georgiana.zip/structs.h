// Copyright 2022 Apetrei Lavinia-Georgiana
#ifndef STRUCTS_H_
#define STRUCTS_H_

#include <stdio.h>
#include <stdlib.h>

#define SMAX 20

typedef struct dll_node_t dll_node_t;
struct dll_node_t
{
    void* data;
    dll_node_t *prev, *next;
};

typedef struct doubly_linked_list_t doubly_linked_list_t;
struct doubly_linked_list_t
{
    dll_node_t* head;
    unsigned int data_size;
    unsigned int size;
};

typedef struct card_t card_t;
struct card_t
{
	int value;
	char symbol[SMAX];
};

typedef unsigned int ui;
#endif  // STRUCTS_H_
